import pygame
import sys
import random
from search_algo import *



pygame.init()

LINE_WIDTH = 1
LINE_COLOR = (255, 255, 255)
CIRCLE_COLOR = (238, 36, 0)
CROSS_COLOR = (0, 255, 0)
BACKGROUND_COLOR = (28, 170, 156)

class Screen:
    def __init__(self):
        self.height = 600  # Corrected typo
        self.width = 600
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.run = True
        self.search_algo = None
        self.algo_choosen = False
        self.font = pygame.font.SysFont('Segoe Print', 30)
        self.graph = pygame.image.load(r"""images\graph.png""")
        self.options = [pygame.image.load(r"""images\m.png"""),
        pygame.image.load(r"""images\A.png"""),
        pygame.image.load(r"""images\mon.png"""),
        pygame.image.load(r"""images\qa.png"""),
        pygame.image.load(r"""images\7lwan.png"""),
        pygame.image.load(r"""images\kitkat.png"""),
        pygame.image.load(r"""images\sadat.png"""),
        pygame.image.load(r"""images\shbra.png"""),
        pygame.image.load(r"""images\rwd.png"""),
        pygame.image.load(r"""images\atba.png"""),
        pygame.image.load(r"""images\shda.png"""),
        pygame.image.load(r"""images\3dly.png""")]
        self.usc = pygame.image.load(r"""images\ucs.png""")
        self.dfs = pygame.image.load(r"""images\dfs.png""")
        self.dls = pygame.image.load(r"""images\dls.png""")
        self.a_star = pygame.image.load(r"""images\a_star.png""")
        self.ids = pygame.image.load(r"""images\a_star.png""")
        self.gcs =pygame.image.load(r"""images\gcs.png""")
        self.LINE_COLOR = ['White', 'White', 'White', 'White', 'White', 'White', 'White']
        self.graph_shown = False
        self.bds = pygame.image.load(r"""images\bds.png""")
        self.start = False
        self.goal = False
        self.path = []
        self.path_img = []
        self.start_chooice = None
        self.end_chooice = None
        self.cliked = False
        self.incircle1 = False
        self.incircle2 = False
        self.limit = 0
        self.circle_radius = 100
        self.circle_cords = [(350, 55),
                              (250, 145),
                                (350, 250),
                                  (250, 350), 
                                  (350, 420), 
                                  (250, 475),
                                  (350, 560), 
                                  (250, 598)]
        self.rectangles = [
            pygame.Rect(50, 50, 500, 50),   
            pygame.Rect(50, 120, 500, 50),  
            pygame.Rect(50, 190, 500, 50),  
            pygame.Rect(50, 260, 500, 50),  
            pygame.Rect(50, 330, 500, 50),  
            pygame.Rect(50, 400, 500, 50),  
            pygame.Rect(50, 470, 500, 50)
        ]
        self.text_list = [
            "Breadth First Search",
            "Uniform Cost Search",
            "Depth-first search (DFS)",
            "Depth-limited search",
            "Iterative Deepening Search",
            "A* Search",
            "Greedy Best First Algorithm"
        ]
        self.clock = pygame.time.Clock()
    def choose_start(self):
        self.draw_circles()
        text = 'Please choose a starting point'
        rendered_text = self.font.render(text, True, 'White')
        self.screen.blit(rendered_text, (70,100,100,100))
        self.screen.blit(self.options[0],(390,220)) 
        self.screen.blit(self.options[1],(85,220)) 
    def draw_path(self):
        circle_radius = 55
        self.limit = len(self.path)
        i = 0
        for a in range(self.limit - 1):  
            if a <= self.limit -1:
                pygame.draw.line(self.screen, (0, 0, 255), self.circle_cords[a], self.circle_cords[a + 1], 2)
                
        for cord in self.circle_cords:
            if i <= self.limit -1 :
                pygame.draw.circle(self.screen, 'Dark Gray', cord, circle_radius)
            i += 1
        self.text_circle()
        pygame.display.flip()
    def convert_path(self):
        pass
        if self.search_algo == 1 or self.search_algo == 5 or self.search_algo == 6:
            for (item,cost) in self.path:
                if item == "المرج":
                    self.path_img.append(self.options[0])
                if item == "عرابى":
                    self.path_img.append(self.options[1])
                if item == "المنيب":
                    self.path_img.append(self.options[2])
                if item == "جامعة القاهرة":
                    self.path_img.append(self.options[3])
                if item == "حلوان":
                    self.path_img.append(self.options[4])
                if item == "الكيت كات":
                    self.path_img.append(self.options[5])
                if item == "السادات":
                    self.path_img.append(self.options[6])
                if item == "شبرا الخيمة":
                    self.path_img.append(self.options[7])
                if item == "محور روض":
                    self.path_img.append(self.options[8])
                if item == "العتبه":
                    self.path_img.append(self.options[9])
                if item == "الشهداء":
                    self.path_img.append(self.options[10])
                if item == "عدلى منصور":
                    self.path_img.append(self.options[11])
        else:
            for item in self.path:
                if item == "المرج":
                    self.path_img.append(self.options[0])
                if item == "عرابى":
                    self.path_img.append(self.options[1])
                if item == "المنيب":
                    self.path_img.append(self.options[2])
                if item == "جامعة القاهرة":
                    self.path_img.append(self.options[3])
                if item == "حلوان":
                    self.path_img.append(self.options[4])
                if item == "الكيت كات":
                    self.path_img.append(self.options[5])
                if item == "السادات":
                    self.path_img.append(self.options[6])
                if item == "شبرا الخيمة":
                    self.path_img.append(self.options[7])
                if item == "محور روض":
                    self.path_img.append(self.options[8])
                if item == "العتبه":
                    self.path_img.append(self.options[9])
                if item == "الشهداء":
                    self.path_img.append(self.options[10])
                if item == "عدلى منصور":
                    self.path_img.append(self.options[11])
    def text_circle(self):
        for index,item in enumerate(self.path_img):
            text_cords_x,text_cords_y = self.circle_cords[index] 
            self.screen.blit(item,(text_cords_x -50,text_cords_y-50))
        print(self.limit)
        print(self.path)
        pygame.display.flip
    def draw_circles(self):
        pygame.display.flip()
        self.circle_radius1,self.circle_radius2 = 100 , 100
        circle_x,circle_y,circle_x2,circle_y2= 450,270,145,270
        self.mouse_x, self.mouse_y = pygame.mouse.get_pos()
        self.color1 = 'Red'
        self.color2 = 'Red'
        self.screen.fill('Black')
        self.distance = ((circle_x - self.mouse_x) ** 2 + (circle_y - self.mouse_y) ** 2) ** 0.5
        self.distance2 = ((circle_x2 - self.mouse_x) ** 2 + (circle_y2 - self.mouse_y) ** 2) ** 0.5
        self.incircle1 = False
        self.incircle2 = False
        if self.distance <= self.circle_radius1:
            self.incircle2 = True
            self.color1 = 'Green'
            self.circle_radius1 = 97
        if self.distance2 <= self.circle_radius2:
            self.incircle1 = True
            self.color2 = 'Green'
            self.circle_radius2 = 97

        circle = pygame.draw.circle(self.screen, self.color1, (circle_x, circle_y), self.circle_radius1)
        circle2 = pygame.draw.circle(self.screen, self.color2, (circle_x2, circle_y2), self.circle_radius2)
        
    def choose_end(self):
        self.draw_circles()
        text = 'Please choose an ending point'
        rendered_text = self.font.render(text, True, 'White')
        self.screen.blit(rendered_text, (70,100,100,100))
        self.screen.blit(self.options[2],(400,220)) 
        self.screen.blit(self.options[3],(85,220)) 
    def get_path(self):
        self.screen.fill('Black')
        self.draw_random_dots()
        if self.search_algo == 0:
            self.path = bfs(graph12, self.start_chooice, self.end_chooice)
        if self.search_algo == 1:
            self.path = ucs(graph2, self.start_chooice, self.end_chooice)
        if self.search_algo == 2:
            self.path = dfs(graph12, self.start_chooice, self.end_chooice)
        if self.search_algo == 3:
            self.path = dls(graph12, self.start_chooice, self.end_chooice,limited=7)
        if self.search_algo == 4:
            self.path = ids(graph12, self.start_chooice, self.end_chooice)
        if self.search_algo == 5:
            self.path = a_star_search(graph121, self.start_chooice, self.end_chooice)
        if self.search_algo == 6:
            self.path = greedy(graph121, self.start_chooice, self.end_chooice)
        
        pygame.display.flip()
    def draw_random_dots(self):
        for _ in range(100):  # Number of dots
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            
            # Skip drawing dots inside any rectangle
            skip_dot = False
            for rect in self.rectangles:
                if rect.collidepoint(x, y):
                    skip_dot = True
                    break
            if not skip_dot:
                pygame.draw.circle(self.screen, 'White', (x, y), 1)

    def buttons(self):
        for i, rect in enumerate(self.rectangles):
            pygame.draw.rect(self.screen, self.LINE_COLOR[i], rect, 3)
    
    def collision(self):
        if not self.algo_choosen:
            for i, rect in enumerate(self.rectangles):
                if rect.collidepoint(self.mouse_x, self.mouse_y):
                    pygame.draw.rect(self.screen, 'Green', rect, 3)
                    return True, i
                else:
                    pygame.draw.rect(self.screen, self.LINE_COLOR[i], rect, 3)
        pygame.display.flip()
        return False, None

    def show_graph(self):
        self.screen.fill('Black')
        self.draw_random_dots()
        self.screen.blit(self.graph, (80, 0))
        pygame.display.update()

    def text(self):
        text_rectangles = [
            pygame.Rect(100, 50, 500, 50),   
            pygame.Rect(100, 120, 500, 50),  
            pygame.Rect(100, 190, 500, 50),  
            pygame.Rect(100, 260, 500, 50),  
            pygame.Rect(100, 330, 500, 50),  
            pygame.Rect(100, 400, 500, 50),  
            pygame.Rect(100, 470, 500, 50)
        ]
        
        for i, text in enumerate(self.text_list):
            rendered_text = self.font.render(text, True, 'White')
            text_rect = text_rectangles[i]
            self.screen.blit(rendered_text, text_rect)

        in_bound, index = self.collision()
        if in_bound:
            rendered_text = self.font.render(self.text_list[index], True, 'Green')
            text_rect = text_rectangles[index]
            self.screen.blit(rendered_text, text_rect)
        pygame.display.flip()

    def algo_screen(self):
        self.screen2 = pygame.display.set_mode((self.width, self.height))
        self.draw_graph()

    def main_loop(self):
        self.draw_random_dots()  
        while self.run:
            if self.search_algo is None:
                self.mouse_x, self.mouse_y = pygame.mouse.get_pos()
            
                self.buttons()  # Draw rectangles
                self.text()  # Draw text and handle rectangle clicks
            if self.graph_shown and self.algo_choosen and not self.start:
                self.choose_start()
            if self.graph_shown and self.algo_choosen and self.start and not self.goal:
                self.choose_end()
            if self.start and self.goal:
                if self.start == 2:
                    self.start_chooice = 'المرج'
                if self.start == 1:
                    self.start_chooice = "عرابى"
                if self.goal == 2:
                    self.end_chooice = "المنيب"
                if self.goal == 1:
                    self.end_chooice = "جامعة القاهرة"
            if self.graph_shown and self.algo_choosen and self.start and self.goal and not self.path:
                self.get_path()
                self.convert_path()
            if self.path:
                self.draw_path()
            for event in pygame.event.get():
                
                if event.type == pygame.QUIT:
                    self.run = False
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if not self.algo_choosen:
                        collide, self.search_algo = self.collision()
                    if self.incircle1:
                        if not self.start:
                            self.start = 1
                        else:
                            self.goal = 1
                    if self.incircle2:
                        if not self.start:
                            self.start = 2
                        else:
                            self.goal = 2
                    
                    if self.search_algo != None:
                        self.algo_choosen = True
                    
                    if self.cliked:
                        self.graph_shown = True
                    if not self.graph_shown and self.algo_choosen:
                            self.show_graph()
                            self.cliked = True
                    

                 
                        
              # Show graph only if graph_shown is True

            self.clock.tick(60)
            pygame.display.flip()  # Update the display

# Initialize and run the main loop
screen1 = Screen()
screen1.main_loop()
