
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                        BREADTH FIRST SEARCH #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


graph12 = {
            "المرج": ["الشهداء"],
            "الشهداء": ["شبرا الخيمة", "عرابى", "العتبه"],
            "شبرا الخيمة": [],
            "عرابى": ["ناصر"],
            "العتبه": ["السادات","عدلى منصور"],
            "ناصر": ["الكيت كات", "السادات", "العتبه", "الشهداء"],
            "السادات": ["العتبه", "جامعة القاهرة", "حلوان"],
            "الكيت كات": ["جامعة القاهرة", "محور روض"],
            "محور روض": [],
            "جامعة القاهرة": ["المنيب"],
            "حلوان": [],
            "المنيب": []
        }

def bfs(graph, start, goal):
    visited = []
    queue = [[start]]
    while queue:
        path = queue.pop(0)
        node = path[-1]
        if node in visited:
            continue
        visited.append(node)
        if node == goal:
            return path
        else:
            adgacent_node = graph.get(node, [])
            for newnode in adgacent_node:
                newpath = path.copy()
                newpath.append(newnode)
                queue.append(newpath)







# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                          DEPTH FIRST SEARCH #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

def dfs(graph, start, goal):
    visited = []
    stack = [[start]]
    while stack:
        path = stack.pop(-1)
        node = path[-1]
        if node in visited:
            continue
        visited.append(node)
        if node == goal:
            return path
        else:
            for newnode in graph.get(node, []):
                newpath = path.copy()
                newpath.append(newnode)
                stack.append(newpath)







# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                        depth limited SEARCH #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


def dls(graph, start, goal, limited=100):
    visited = []
    stack = [[start]]
    while stack:
        path = stack.pop(-1)
        node = path[-1]
        if node in visited:
            continue
        visited.append(node)
        if len(path) > limited:
            break
        if node == goal:
            return path
        else:
            adgacent_node = graph.get(node, [])
            for new_node in adgacent_node:
                new_path = path.copy()
                new_path.append(new_node)
                stack.append(new_path)
    return None








# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                        Iterative deepening search #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


def ids(graph, start, goal):
    def dls(graph, start, goal, limit):
        limited = 0
        visited = []
        stack = [[start]]
        while stack:
                path = stack.pop(-1)
                node = path[-1]
                if node in visited:
                    continue
                visited.append(node)
                if node == goal:
                    return path
                if limit < len(path):
                    continue
                else:
                    adgacent_node = graph.get(node, [])
                    for new_node in adgacent_node:
                        new_path = path.copy()
                        new_path.append(new_node)
                        stack.append(new_path)
    depth = 0
    while True:
        result = dls(graph, start, goal, depth)
        if result != None:
            return result
        depth += 1









# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                        uniform cost SEARCH #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
graph2 = {
            "المرج": [("الشهداء", 12)],
            "الشهداء": [("شبرا الخيمة",7), ("عرابى",1), ("العتبه",1)],
            "شبرا الخيمة": [],
            "عرابى": [("ناصر",1)],
            "العتبه": [("عدلى منصور",18)],
            "ناصر": [("الكيت كات",3), ("السادات",1), ("العتبه",1), ("الشهداء",3)],
            "السادات": [("العتبه",1), ("جامعة القاهرة",4), ("حلوان",18)],
            "الكيت كات": [("جامعة القاهرة",5), ("محور روض",6)],
            "محور روض": [],
            "جامعة القاهرة": [("المنيب",5)],
            "حلوان": [],
            "المنيب": []
        }

def cost_path_uniform(path):
    total_cost = 0
    for (node, cost) in path:
        total_cost += cost
        path = node
    return total_cost, path       

def ucs(graph, start, goal):
    visited = []
    queue = [[(start,0)]]
    while queue:
        queue.sort(key = cost_path_uniform)
        path = queue.pop(0)
        node = path[-1][0]
        if node in visited:
            continue
        visited.append(node)
        if node == goal:
            return path
        else:
            adgacent_node = graph.get(node, [])
            for new_node in adgacent_node:
                new_path = path.copy()
                new_path.append(new_node)
                queue.append(new_path)
            
  








# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                           Greedy Best first search #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

graph121 = {
    "المرج": [("الشهداء", 12)],
    "الشهداء": [("شبرا الخيمة", 7), ("عرابى", 1), ("العتبه", 1)],
    "شبرا الخيمة": [],
    "عرابى": [("ناصر", 1)],
    "العتبه": [("عدلى منصور", 18)],
    "ناصر": [("الكيت كات", 3), ("السادات", 1), ("العتبه", 1), ("الشهداء", 3)],
    "السادات": [("العتبه", 1), ("جامعة القاهرة", 4), ("حلوان", 18)],
    "الكيت كات": [("جامعة القاهرة", 5), ("محور روض", 6)],
    "محور روض": [],
    "جامعة القاهرة": [("المنيب", 5)],
    "حلوان": [],
    "المنيب": []
}


def Gpath_cost(path):
    heuristic = {
    "المرج": 13,
    "الشهداء": 13,
    "شبرا الخيمة": -1,  # No path to goal
    "عرابى": 10,
    "العتبه": 19,
    "ناصر": 9,
    "السادات": 6,
    "الكيت كات": 10,
    "محور روض": -1,  # No path to goal
    "جامعة القاهرة": 5,
    "حلوان": -1,  # No path to goal
    "المنيب": 0
}
    G_cost = 0
    # Sum up the costs for each node in the path
    for (node, cost) in path:
        G_cost += cost
    # Get the last node in the path
    last_node = path[-1][0]
    # Get the heuristic value for the last node
    Hcost = heuristic[last_node]
    return Hcost, last_node

def greedy(graph, start, goal):
    visited = []  # List to keep track of visited nodes
    queue = [[(start, 0)]]  # Start with the initial node and cost 0

    while queue:
        # Sort the queue based on the heuristic value (Greedy best-first search)
        queue.sort(key=lambda path: Gpath_cost(path)[0])  # Sort by Hcost
        path = queue.pop(0)  # Pop the path with the lowest Hcost
        node = path[-1][0]   # Get the last node in the current path
        
        # If the node has already been visited, skip it
        if node in visited:
            continue
        
        # Mark the node as visited
        visited.append(node)
        
        # If we've reached the goal, return the path
        if node == goal:
            return path
        
        # Otherwise, explore the neighbors of the current node
        adj_nodes = graph.get(node, [])
        for (node2, cost) in adj_nodes:
            # Create a new path by adding the current node's neighbor
            newpath = path.copy()
            newpath.append((node2, cost))  # Add the new node and its cost to the path
            queue.append(newpath)  # Add the new path to the queue
    
    return None  # If no path is found








# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#                                 A* search #
# \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
graph121 = {
    "المرج": [("الشهداء", 12)],
    "الشهداء": [("شبرا الخيمة", 7), ("عرابى", 1), ("العتبه", 1)],
    "شبرا الخيمة": [],
    "عرابى": [("ناصر", 1)],
    "العتبه": [("عدلى منصور", 18)],
    "ناصر": [("الكيت كات", 3), ("السادات", 1), ("العتبه", 1), ("الشهداء", 3)],
    "السادات": [("العتبه", 1), ("جامعة القاهرة", 4), ("حلوان", 18)],
    "الكيت كات": [("جامعة القاهرة", 5), ("محور روض", 6)],
    "محور روض": [],
    "جامعة القاهرة": [("المنيب", 5)],
    "حلوان": [],
    "المنيب": []
}

def cost_path(path, heuristic):
    total_cost = 0
    for (node, cost) in path:
        total_cost += cost
        last_node = node
    # f(n) = g(n) + h(n)
    f_fun = total_cost + heuristic[last_node]
    return f_fun

def a_star_search(graph, start, goal):
    heuristic = {
    "المرج": 13,
    "الشهداء": 13,
    "شبرا الخيمة": -1,  # No path to goal
    "عرابى": 10,
    "العتبه": 19,
    "ناصر": 9,
    "السادات": 6,
    "الكيت كات": 10,
    "محور روض": -1,  # No path to goal
    "جامعة القاهرة": 5,
    "حلوان": -1,  # No path to goal
    "المنيب": 0
}
    visited = set()  # To avoid revisiting nodes
    queue = [[(start, 0)]]  # Start with the initial node and cost 0

    while queue:
        # Sort the queue based on the f(n) value (which is cost_path)
        queue.sort(key=lambda path: cost_path(path, heuristic))
        
        path = queue.pop(0)  # Pop the path with the lowest f(n)
        node = path[-1][0]   # Get the last node in the path
        
        # If the node has already been visited, skip it
        if node in visited:
            continue
        
        visited.add(node)
        
        # Check if we have reached the goal
        if node == goal:
            return path
        
        # Get the adjacent nodes for the current node
        adjacent_nodes = graph.get(node, [])
        
        for new_node, cost in adjacent_nodes:
            if new_node not in visited:  # Only explore unvisited nodes
                new_path = path.copy()
                new_path.append((new_node, cost))  # Add the new node with its cost to the path
                queue.append(new_path)
    
    return None  # If no path is found

# Define the graph and heuristic as in the problem






# Example usage of the A* search function



  









